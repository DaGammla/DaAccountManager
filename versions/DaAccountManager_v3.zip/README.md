# Da Account Manager
This software is an account manager written in Java.
I made it for myself as I don't trust other account holding softwares and
because hackers won't look for some no name account managing software save files
